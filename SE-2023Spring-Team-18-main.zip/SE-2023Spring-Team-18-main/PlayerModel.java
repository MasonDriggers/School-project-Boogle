package Model;
import java.util.ArrayList;

import DataAccess.PlayerDataAccess;
import DataObject.PlayerDataObject;
import DomainObject.GameDomainObject;
import DomainObject.PlayerDomainObject;
import restService.Message;


public class PlayerModel {
	
	public static PlayerDomainObject GetPlayerById(Message message, int id) {
		PlayerDataObject playerData = PlayerDataAccess.getPlayerById(id);
		PlayerDomainObject playerDomain = new PlayerDomainObject(playerData);
		return playerDomain;
	}

	public static ArrayList<PlayerDomainObject> GetAllPlayers(Message messasge) {
		ArrayList<PlayerDataObject> playerDataList = PlayerDataAccess.getAllPlayers();
		ArrayList<PlayerDomainObject> playerDomainList = PlayerDomainObject.MapList(playerDataList);
		return playerDomainList;
	}



	public static boolean ValidatePlayerById(int id) {
		if (PlayerDataAccess.getPlayerById(id) == null)
			return false;
		return true;
	}
	
	public static PlayerDomainObject RegisterPlayer(Message message, PlayerDomainObject domainPlayerToCreate) {
		//This needs to be implemented.
		//error messages(Strings)
		String DuplicateID = "This username is already taken.";
		String BadUserName = "Invalid username.  The username must contain between 6 and 12 characters and must only contain English letters and numbers.";
		String BadPassword = "Invalid password.  The password must contain between 6 and 12 characters and must only contain English letters and numbers.";
		
		PlayerDataObject p1 = new PlayerDataObject(-1,domainPlayerToCreate.userName , domainPlayerToCreate.password);
		
		//check to see if username's length is valid
		if(p1.userName.length() < 6 || p1.userName.length() > 12 || p1.userName == null) {
			message.addErrorMessage(BadUserName);
		}
		//checks that the username characters are only letters and numbers
		for (int i=0; i < p1.userName.length(); i++) {
			if (Character.isLetterOrDigit(p1.userName.charAt(i)) == false) {
				message.addErrorMessage(BadUserName);
			}
		}
		//checks the length of the entered password, to see if it meets standards
		if(p1.password.length() < 6 || p1.password.length() > 12 || p1.password == null) {
			message.addErrorMessage(BadPassword);
		}
		//validates whether any of the password's characters is not a letter or digit
		for (int i=0; i< p1.password.length(); i++) {
			if (Character.isLetterOrDigit(p1.password.charAt(i)) == false) {
				message.addErrorMessage(BadPassword);
			}
		}

		//get all the players available
		ArrayList<PlayerDataObject> players = PlayerDataAccess.getAllPlayers();
		
		//Compare the current username to any that may already reside within the players arraylist in PlayerDataAccess
		for (int i = 0; i < players.size(); i++) {
			if (p1.userName.equalsIgnoreCase(players.get(i).userName)) {
				message.addErrorMessage(DuplicateID);
			}
		}

		PlayerDataObject DataPlayerToCreate = new PlayerDataObject(p1.id, p1.userName, p1.password);
		PlayerDataObject doPlayerCreated = PlayerDataAccess.createPlayer(DataPlayerToCreate);
		PlayerDomainObject domainPlayerCreated = new PlayerDomainObject(doPlayerCreated);
		
		return domainPlayerCreated;
	}


}
