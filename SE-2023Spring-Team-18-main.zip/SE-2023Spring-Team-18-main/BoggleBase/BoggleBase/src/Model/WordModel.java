package Model;
import java.util.ArrayList;

import Controller.GameController;
import DataAccess.GameDataAccess;
import DataAccess.PlayerDataAccess;
import DataAccess.WordDataAccess;
import DataObject.GameDataObject;
import DataObject.WordDataObject;
import DomainObject.WordDomainObject;
import restService.Message;


public class WordModel {
	
	public static WordDomainObject getWordById(Message message, int id) {
		WordDataObject wordData = WordDataAccess.getWordById(id);
		WordDomainObject wordDomain = new WordDomainObject(wordData);
		return wordDomain;
	}

	public static ArrayList<WordDomainObject> getAllWordsForGameAndPlayer(Message messasge, int gameId, int playerId) {
		ArrayList<WordDataObject> wordDataList = WordDataAccess.getAllWordsForGameAndPlayer(gameId, playerId);
		ArrayList<WordDomainObject> wordDomainList = WordDomainObject.MapList(wordDataList);
		return wordDomainList;
	}

	public static WordDomainObject GuessWord(Message message, WordDomainObject domainWordToCreate) {
		String wrongGId = "The Game Id provided is an invalid game id.";
		String wrongPId = "The player provided is not valid for the game.";
		String comGame = "This game is already completed.";
		String failSaveWord = "The word is not valid.  It must be at least 4 characters long and include only letters.";
		WordDataObject W1 = new WordDataObject(domainWordToCreate.id, domainWordToCreate.gameId, domainWordToCreate.playerId, domainWordToCreate.word, false, domainWordToCreate.score);
		
		GameDataObject gamma = GameDataAccess.getGameById(W1.gameId);

		W1.isValid = ValidateWord(message, W1.word);
		

		//checks for a valid playerID
		if(PlayerDataAccess.getPlayerById(W1.playerId) == null){
			message.addErrorMessage(wrongPId);
		}
		
		//checks if the word is saved 
		if (W1.isValid == true){
			WordDataAccess.createWord(W1);
		}
		else {
			message.addErrorMessage(failSaveWord);
		}

		//checks for invalid game ID
		if(W1.gameId > 2) {
			message.addErrorMessage(wrongGId);
		}

		//checks for non digits
		if(!LetterCheck(W1.word)){
			message.addErrorMessage(failSaveWord);
		}
		

		//checks if game is completed
		if(gamma.gameStatus == "Complete"){
			message.addErrorMessage(comGame);
		}
		
		//assigns appropriate score
		if(W1.isValid == true) {
			W1.score = ScoreSetup(W1.word);
		}

		WordDataObject domainWordCreated = WordDataAccess.createWord(W1);
		WordDomainObject WordCreated = new WordDomainObject(domainWordCreated);
		return WordCreated;
	}

	public static boolean ValidateWord(Message message, String word) {
		boolean isValid = false;
		if(word.length() <= 3){
			isValid = false;
		}
		else{
			isValid = true;
		}
		return isValid;		
	}

	//method to check for nonletters
	public static boolean LetterCheck(String word) {
		boolean ValidC = true;
		char[] WordC = word.toCharArray();
		for (int i =0; i < WordC.length; i++){
			if(!Character.isLetter(WordC[i])){
				ValidC = false;
			}
		}
		return ValidC;
	}
	
public static int ScoreSetup(String word) {
	int Wscore = 0;


	if(word.length() == 4){
		Wscore = 1;
	}

	else if(word.length() == 5){
		Wscore = 2;
	}

	else if(word.length() == 6){
		Wscore = 3;
	}
	else if(word.length() == 7){
		Wscore = 5;
	}

	else if(word.length() >= 8){
		Wscore = 11;
	}
	return Wscore;
}

}
