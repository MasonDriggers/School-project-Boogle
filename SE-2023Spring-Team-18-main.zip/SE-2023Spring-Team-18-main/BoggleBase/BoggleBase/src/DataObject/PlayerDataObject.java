package DataObject;

public class PlayerDataObject {

	public int id;
	public String userName;
	public String password;

	public PlayerDataObject (int id, String userName, String password) {
		this.id = id;
		this.userName = userName;
		this.password = password;
	}

}