package DataObject;

public class BoardDataObject {

	public int id;
	public int gameId;
	public String g1;
	public String g2;
	public String g3;
	public String g4;
	public String g5;
	public String g6;
	public String g7;
	public String g8;
	public String g9;
	public String g10;
	public String g11;
	public String g12;
	public String g13;
	public String g14;
	public String g15;
	public String g16;

	public BoardDataObject (int id, int gameId, String g1, String g2, String g3, String g4, String g5, String g6, String g7, String g8, String g9, String g10, String g11, String g12, String g13, String g14, String g15, String g16 ) {
		this.id = id;
		this.gameId = gameId;
		this.g1 = g1;
		this.g2 = g2; 
		this.g3 = g3;
		this.g4 = g4; 
		this.g5 = g5; 
		this.g6 = g6;
		this.g7 = g7;
		this.g8 = g8; 
		this.g9 = g9;
		this.g10 = g10; 
		this.g11 = g11; 
		this.g12 = g12;
		this.g13 = g13;
		this.g14 = g14; 
		this.g15 = g15;
		this.g16 = g16; 
	}	

}