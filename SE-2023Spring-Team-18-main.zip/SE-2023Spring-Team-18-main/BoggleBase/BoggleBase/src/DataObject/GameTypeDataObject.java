package DataObject;

public class GameTypeDataObject {

	public int id;
	public String name;

	public GameTypeDataObject (int id, String name) {
		this.id = id;
		this.name = name;
	}

}